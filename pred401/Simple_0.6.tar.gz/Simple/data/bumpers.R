"bumpers" <-
structure(c(618, 795, 1304, 1308, 1340, 1456, 1500, 1600, 1969, 
1999, 2008, 2129, 2247, 2284, 2357, 2381, 2546, 3002, 3096, 3113, 
3201, 3266, 3298), .Names = c("Honda Accord", "Chevrolet Cavalier", 
"Toyota Camry", "Saturn SL2", "Mitsubishi Galant", "Dodge Monaco", 
"Plymouth Acclaim", "Chevrolet Corsica", "Pontiac Sunbird", "Oldsmobile Calais", 
"Dodge Dynasty", "Chevrolet Lumina", "Ford Tempo", "Nissan Stanza", 
"Pontiac Grand Am", "Buick Century", "Buick Skylark", "Ford Taurus", 
"Mazda 626", "Oldsmobile Ciere", "Pontiac 6000", "Subaru Legacy", 
"Hyundai Sonata"))
