"chicken" <-
structure(list(Ration1 = c(4, 4, 7, 3, 2, 5, 4, 5, 2, 3, 6, 4, 
5), Ration2 = c(3, 4, 5, 4, 6, 4, 5, 6, 7, 6, 5, 5, 5), Ration3 = c(6, 
7, 7, 7, 6, 8, 5, 6, 7, 6, 7, 5, 6)), .Names = c("Ration1", "Ration2", 
"Ration3"), row.names = c("1", "2", "3", "4", "5", "6", "7", 
"8", "9", "10", "11", "12", "13"), class = "data.frame")
